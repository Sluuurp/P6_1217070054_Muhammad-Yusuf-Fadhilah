#Muhammad Yusuf Fadhilah
#1217070054
import cv2
import numpy as np

img = cv2.imread('C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/4/gura.jpeg', 0)
 
equ = cv2.equalizeHist(img)

res = np.hstack((img, equ))

cv2.imshow('C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/4/gura.jpeg', res)
cv2.waitKey(0)
cv2.destroyAllWindows()