#Muhammad Yusuf Fadhilah
#1217070054
import cv2
import numpy as np

img = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/4/gura.jpeg")

im2 = 225 - img

cv2.imshow('C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/4/gura.jpeg', im2)
cv2.waitKey(0)
cv2.destroyAllWindows